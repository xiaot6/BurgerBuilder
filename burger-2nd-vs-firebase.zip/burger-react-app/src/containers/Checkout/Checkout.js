import React, { Component } from 'react';


class Checkout extends Component {

}

export default Checkout;

