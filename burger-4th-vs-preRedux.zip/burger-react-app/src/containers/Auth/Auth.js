import React, { Component } from 'react';

class Auth extends Component{
    satte = {
        
    }

    render() {
        return (
            <div>
                <form> 

                </form>
            </div>
        );

    }
}

export default Auth; 